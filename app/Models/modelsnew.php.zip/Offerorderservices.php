<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Offerorderservices extends Model
{
    use HasFactory;
    public $fillable = ['servicename','servicevalue','offer_id','confirmation'];

    public function offerorder()
    {
        return $this->belongsTo('App\Models\offerorder');
    }
}
