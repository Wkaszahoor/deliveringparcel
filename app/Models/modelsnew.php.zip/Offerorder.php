<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Offerorder extends Model
{
    use HasFactory;
    public $fillable = ['shipingaddress','shippingaddress_id','description','total','order_id','offer_status','product_total','rejections_note' ,'approximate_weight'];

    public function offerorderservices()
    {
        return $this->hasMany('App\Models\offerorderservices');
    }
    public function offerorderproducts()
    {
        return $this->hasMany('App\Models\offerorderproducts');
    }
}
