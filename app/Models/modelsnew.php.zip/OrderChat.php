<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderChat extends Model
{
    use HasFactory;
    public $fillable = ['from', 'body', 'order_id','image','read'];
    
    public function orders()
    {
        return $this->belongsTo('App\Models\orders');
    }
}
