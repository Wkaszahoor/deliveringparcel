<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Stripe;
// use Stripe\Stripe;

class StripeController extends Controller
{
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function stripe()
    {
        $stripe = new Stripe\StripeClient('sk_test_51H7W7uGptPHWj9q0yFxmpbBxYlhoLEKD7CmCPJEhE3gBFcfrgRZ3wf2bXJ5XDvAxpYm4XMAblygNR24lZQyBjOS300WUadLpYL');
        // $customers = $stripe->customers->all();
    //     $customers = $stripe->balance->retrieve();
    //     dd($customers);
    //    $payment= $stripe->paymentIntents->retrieve(
    //         'cus_J6S1lz6WX74MWe',
    //         []
    //     );
    //     dd($payment);
        return view('stripe');
    }
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function stripePost(Request $request)
    {
        // dd($request);
        Stripe\Stripe::setApiKey('sk_test_51H7W7uGptPHWj9q0yFxmpbBxYlhoLEKD7CmCPJEhE3gBFcfrgRZ3wf2bXJ5XDvAxpYm4XMAblygNR24lZQyBjOS300WUadLpYL');
        Stripe\Charge::create([
            "amount" => 100 * 100,
            "currency" => "usd",
            "source" => $request->stripeToken,
            "description" => "This payment is tested purpose phpcodingstuff.com"
        ]);

        // Session::flash('success', 'Payment successful!');
        session()->flash('success', 'Payment successful!');

        return back();
    }
}
