<?php

namespace App\Http\Controllers;

use App\Mail\Free_quoteEmail;
use App\Models\RequestQuote;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class FreeQuoteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $freequote = RequestQuote::all();
        // dd($freequote);
        return view('admin.freequote.index', compact('freequote'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        if ($request->user_id == "user-invalid"){
            $request->validate([
                'name' => 'required',
                'email' => 'required',
                'number' => 'required|max:20',
                'cargotype' => 'required',
                'country' => 'required',
                'destination' => 'required',
                'weight' => 'required',
                'width' => 'required',
                'height' => 'required',
                'detail' => 'required',
            ]);
            $freequote = new RequestQuote([
                'name' => $request->name,
                'email' => $request->email,
                'number' => $request->number,
                'cargotype' => $request->cargotype,
                'country' => $request->country,
                'destination' => $request->destination,
                'weight' => $request->weight,
                'width' => $request->width,
                'height' => $request->height,
                'detail' => $request->detail,
            ]);
            $freequote->save();
            $details = [
                'title' => 'Free quote is requested by',
                'name' => $request->name,
                'email' => $request->email,
                'number' => $request->number,
                'cargotype' => $request->cargotype,
                'country' => $request->country,
                'destination' => $request->destination,
                'weight' => $request->weight,
                'width' => $request->width,
                'height' => $request->height,
                'detail' => $request->detail,
            ];
            Mail::to('sales@deliveringparcel.com')->send(new Free_quoteEmail($details));
            return back()->with('success', 'Your response is send successfully');
        }else{
            $request->validate([
                'cargotype' => 'required',
                'country' => 'required',
                'destination' => 'required',
                'weight' => 'required',
                'width' => 'required',
                'height' => 'required',
                'detail' => 'required',
            ]);
            $user = $request->user_id;
            $user_name = User::where('id', $request->user_id)->first();
            $freequote = new RequestQuote([
                'name' => $user_name->name,
                'email' => $user_name->email,
                'number' => $user_name->number,
                'cargotype' => $request->cargotype,
                'country' => $request->country,
                'destination' => $request->destination,
                'weight' => $request->weight,
                'width' => $request->width,
                'height' => $request->height,
                'detail' => $request->detail,
            ]);
            $freequote->save();
            $details = [
                'title' => 'Free quote is requested by',
                'name' =>  $user_name->name,
                'email' => $user_name->email,
                'number' => $user_name->number,
                'cargotype' => $request->cargotype,
                'country' => $request->country,
                'destination' => $request->destination,
                'weight' => $request->weight,
                'width' => $request->width,
                'height' => $request->height,
                'detail' => $request->detail,
            ];
            Mail::to('sales@deliveringparcel.com')->send(new Free_quoteEmail($details));
            return back()->with('success', 'Your response is send successfully');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // dd($id);
        $freequote = RequestQuote::where('id',$id)->get();
        // dd($freequote);
        return view('admin.freequote.show', compact('freequote'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         $address = RequestQuote::find($id);
        $address->delete();
        return redirect(route('freequote.index'))->with('success', 'Quote Deleted successfuly');
    }

    
}
