<?php

namespace App\Http\Controllers;

use App\Mail\contactus as MailContactus;
use App\Models\Contactus;
use App\Models\Orders;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class ClientsController extends Controller
{
    public function index(){
        $users = User::all();
        // dd($users);
        $orders = User::join('orders', 'orders.user_id', '=', 'users.id')
                            ->groupBy('users.id')
                            ->orderBy(DB::raw("users.created_at"), 'desc')
                            ->get(['users.id', 'users.name', 'users.email', 'users.number', DB::raw('count(orders.id) as orders_items')]);

        // dd($orders);
        return view('admin.clients', compact('orders'));
    }
    public function show($id)
    {
        // dd($id);
        $user = User::find($id);
        $orders = Orders::where('user_id',$id)->orderBy(DB::raw("orders.created_at"), 'desc')->get();
        // dd($orders);
        return view('admin.client_detail', compact('orders','user'));
    }
    public function contactus(Request $request)
    {
        // dd($request->all());
        $this->validate($request, [
            'name'     => 'required',
            'email'     => 'required',
            'number' => 'required',
            'address' => 'required',
            'message' => 'required',
        ]);

        $contact = new Contactus([
            'name'     => $request->name,
            'email'     => $request->email,
            'number' => $request->number,
            'address' => $request->address,
            'detail' => $request->message,
        ]);

        $contact->save();
        $details = [
            'title' => 'contacted us on Deliveringparcel',
            'name'     => $request->name,
            'email'     => $request->email,
            'number' => $request->number,
            'address' => $request->address,
            'message' => $request->message,
        ];
        Mail::to('service@deliveringparcel.com')->send(new MailContactus($details));
        return back()->with('success', 'Your response is send successfully');
    }
    
}
