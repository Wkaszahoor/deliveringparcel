<?php

namespace App\Http\Controllers;

use App\Models\Contactus;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\contactus as MailContactus;

class ContactedusController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $contact = Contactus::all();
        // dd($contact);
        return view('admin.contact_us.index', compact('contact'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name'     => 'required',
            'email'     => 'required',
            'number' => 'required',
            'address' => 'required',
            'message' => 'required',
        ]);
        $contact = new Contactus([
            'name'     => $request->name,
            'email'     => $request->email,
            'number' => $request->number,
            'address' => $request->address,
            'detail' => $request->message,
        ]);
        $contact->save();
        $details = [
            'title' => 'contacted us on Deliveringparcel',
            'name'     => $request->name,
            'email'     => $request->email,
            'number' => $request->number,
            'address' => $request->address,
            'message' => $request->message,
        ];
        Mail::to('service@deliveringparcel.com')->send(new MailContactus($details));
        return back()->with('success', 'Your response is send successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $Contactus = Contactus::where('id', $id)->get();
        // dd($freequote);
        return view('admin.contact_us.show', compact('Contactus'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $address = Contactus::find($id);
        $address->delete();
        return redirect(route('contactus.index'))->with('success', 'Contacted us details Deleted successfuly');
    }
}
