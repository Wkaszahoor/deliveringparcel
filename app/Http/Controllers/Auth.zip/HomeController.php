<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
    public function password(){
        $user = User::find(auth()->user()->id);
        return view("clients.profile",[
            'user'=>$user
        ]);
    }
    public function changePassword(Request $request){
        // dd($request->all());
        $this->validate($request, [
            'old_password'     => 'required',
            'new_password'     => 'required|min:6',
            'confirm_password' => 'required|same:new_password',
        ]);
        $data = $request->all();
        $user = User::find(auth()->user()->id);
        // dd($user);
        if(!Hash::check($data['old_password'], $user->password)){
            return back()->with('error','You have Entered Wrong Password');
        }
        else{
            $user->password = Hash::make($request->new_password);
            if ($user->save()) {
                return Redirect("password")->with('success', 'Password is Updated Successfully!');
            } 
        }
    } 

    
}
