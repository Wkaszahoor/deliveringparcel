<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
// use Auth;
use Illuminate\Support\Facades\Auth;


class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    // protected $redirectTo = RouteServiceProvider::HOME;

    // protected $redirectTo = '/dashboard';
    protected function redirectTo(){
         $user_role = Auth::user()->roles[0]->slug;
        //  dd('hello');
        // if($user_role =='admin'){
        //     return 'admin-dashbord';
        // }
        //  else{
        //      return  'client-dashbord';
        //  }
        
        if($user_role =='admin'){
            return 'admin-orders';
        }
        else{
            return  'dashboard';
        }
    }

    public function logout(Request $request) {
        Auth::logout();
        return redirect(route('/'));
    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
}
