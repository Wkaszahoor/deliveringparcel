<?php

namespace App\Http\Controllers;

use App\Mail\Login_Mail;
use Notification;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Hash;
use App\Models\Orders;
use App\Models\Orderproducts;
use App\Models\Offerorder;
use App\Models\Offerorderproducts;
use App\Models\Offerorderservices;
use Illuminate\Support\Facades\Mail;
use App\Mail\Loginmail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use App\Models\OrderChat;
use App\Models\ShippingAddresses;
use Session;
use Stripe;
use Illuminate\Support\Facades\DB;

class OrdersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function index()
    {
        $id = Auth::user()->id;
        $order = Orders::where('user_id',$id)->orderBy("orders.created_at", 'desc')->get();
        // $offer = Offerorder::find($address->id)->first();
        // $offer = Orders::select('*', 'orders.id AS id')
        //     ->join('offerorders','orders.id' ,'=','offerorders.order_id')
        //     ->where('user_id',$id)
        //     ->get();
        return view('clients.orders',compact('order'));
    }
    public function country(Request $request)
    {
    //    dd($request->all());
        $data = ["from" => $request->from, "to" => $request->to];
        // dd($data);
        return view('specialrequest', compact('data'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        if (Orders::all()->count() > 0) {
            $last_id = DB::table('orders')->latest()->first()->order_id;
            $order_id = $last_id + 1;
        } else {
            $order_id = 1001;
        }
        // dd('else');
        // verifying if email already exist 

        $users = User::where('email', '=', $request->input('email'))->first();
        
        if ($users != null) {
            return back()->with('error','This Email is already Registered. Please Login First.');
        } 
        else {
            
             // if user is not registered then this code will execute
            if ($request->user_id == "user-invalid") {
                // dd('hello');
                $request->validate([
                    'name'=> 'required',
                    'email'=> 'required',
                    'number'=>'required|max:20',
                    'shipfrom'=>'required',
                    'shipto'=>'required',
                    'postalcode'=>'required|max:10',
                    'address'=>'required',
                    'approximate_weight'=>'required|max:20',
                    'product_services'=>'required',
                    'total'=>'required',
                    'addmore.*.producturl' => 'required',
                    'addmore.*.productquantity' => 'required',
                    'addmore.*.productweight' => 'required',
                ]);
            $hashedRandomPassword = Str::random(12);
            $random_orderid = Str::random(6);

                // creating new role for newly registered users or clients 
                // $data = array(
                //     'name' => $request->name,
                //     'email' => $request->email,
                //     'password'=>$hashedRandomPassword,
                // );
                // Mail::to($request->email)->send(new Loginmail($data));
                $details = [
                    'title' => $request->name,
                    'email' => $request->email,
                    'password'=>$hashedRandomPassword,
                    'url' => route('login')
                ];

                Mail::to($request->email)->send(new Login_Mail($details));

            $dev_role = new Role();
            $dev_role->slug = 'client';
            $dev_role->name = 'Client';
            $dev_role->save();
            
            // Saving newly registered users 
            $user = new User([
                'name' => $request->name,
                'email' => $request->email,
                'number' => $request->number,
                'type' => 'client',
                'password' =>  Hash::make($hashedRandomPassword ),
            ]);
            $user->save();
            $user->roles()->attach($dev_role);

            $order = new Orders([
                'user_id' => $user->id,
                'shipfrom' => $request->shipfrom,
                'shipto' => $request->shipto,
                'postalcode' => $request->postalcode,
                'address' => $request->address,
                'approximate_weight' => $request->approximate_weight,
                'product_services' => $request->product_services,
                'product_photo' => $request->product_photo,
                'product_check' => $request->product_check,
                'product_customs' => $request->product_customs,
                'product_prohibited' => $request->product_prohibited,
                'product_disinfection' => $request->product_disinfection,
                'product_consolidation' => $request->product_consolidation,
                'product_purchase' =>$request->purchase_assistence,
                'total' => $request->total,
                'order_id'=> $order_id,
                'product_totalprice'=>$request->total_price,
                // "order_status" => 'Request Submitted'
            ]);
            $order->save();
            foreach ($request->addmore as $key => $value) {
                    $product = new Orderproducts([
                        'order_id' => $order->id,
                        'productname' => $value['productname'],
                        'producturl' => $value['producturl'],
                        'productquantity' => $value['productquantity'],
                        'productprice' => $value['productprice'],
                        'product_total' => $value['producttotal'],
                        'productweight' => $value['productweight'],
                    ]);
                    $product->save();
                }
                // $user = User::find(1);
                $admin = User::where('type', 'admin')->first();
                // $user_name = User::where('id', $request->user_id)->first();
                $details = [

                    'title' => 'Notification on Order #' . $order_id . ' from Shopper',
                    'order_number' => $order_id,
                    'greeting' => $request->name. ' place order',
                    'order_id' => $order->id,
                    'description' => ''
                ];
                $admin->notify(new \App\Notifications\TaskNotification($details));
                $client = User::where('id', $user->id)->first();
                // dd($client);
                $details = [

                    'title' => 'Your request has been placed with the order number # ' . $order_id,
                    'order_number' => $order_id,
                    'greeting' => 'Request Placed',
                    'order_id' => $order->id,
                    'description' => 'Please check the dashboard for the status and you will soon get an offer which will be notified by email as well.'
                ];
                $client->notify(new \App\Notifications\TaskNotification($details));

            return redirect(route('request'))->with('success','Login detail sent to your email address');
            } 
            // if user is logined then this code will execute
            else {
                $request->validate([
                    'shipfrom'=>'required',
                    'shipto'=>'required',
                    'postalcode'=>'required|max:10',
                    'address'=>'required',
                    'approximate_weight'=>'required|max:20',
                    'product_services'=>'required',
                    'total'=>'required',
                    'addmore.*.producturl' => 'required',
                    'addmore.*.productquantity' => 'required',
                    'addmore.*.productweight' => 'required',
                ]);
                $user = $request->user_id;
                $user_name=User::where('id',$request->user_id)->first();
                $order = new Orders([
                        'user_id' => $user,
                        'shipfrom' => $request->shipfrom,
                        'shipto' => $request->shipto,
                        'postalcode' => $request->postalcode,
                        'address' => $request->address,
                        'approximate_weight' => $request->approximate_weight,
                        'product_services' => $request->product_services,
                        'product_photo' => $request->product_photo,
                        'product_check' => $request->product_check,
                        'product_customs' => $request->product_customs,
                        'product_prohibited' => $request->product_prohibited,
                        'product_disinfection' => $request->product_disinfection,
                        'product_consolidation' => $request->product_consolidation,
                        'product_purchase' =>$request->purchase_assistence,
                        'total' => $request->total,
                        'order_id'=> $order_id,
                        'product_totalprice'=>$request->total_price
                ]);
                $order->save();
                foreach ($request->addmore as $key => $value) {
                    $product = new Orderproducts([
                        'order_id' => $order->id,
                        'productname' => $value['productname'],
                        'producturl' => $value['producturl'],
                        'productquantity' => $value['productquantity'],
                        'productprice' => $value['productprice'],
                        'product_total' => $value['producttotal'],
                        'productweight' => $value['productweight'],
                    ]);
                    $product->save();
                }
                // $user = User::find(1);
                $admin = User::where('type','admin')->first();
                // dd($user);
                    $details = [
                            'title' => 'Notification on Order #' . $order_id . ' from Shopper',
                            'order_number' => $order_id,
                            'greeting' =>  $user_name->name. ' place order',
                            'order_id' => $order->id,
                            'description' => ''
                    ];
                    $admin->notify(new \App\Notifications\TaskNotification($details));

                $client = User::where('id', $request->user_id)->first();
                $details = [

                    'title' => 'Your request has been placed with the order number # ' . $order_id,
                    'order_number' => $order_id,
                    'greeting' => 'Request Placed',
                    'order_id' => $order->id,
                    'description'=> 'Please check the dashboard for the status and you will soon get an offer which will be notified by email as well.'
                ];
                $client->notify(new \App\Notifications\TaskNotification($details));
                return redirect(route('request'))->with('success','Request detail submitted successfully'); 
            }                       
        }       
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // dd($id);
        $order = Orders::select('*', 'orders.id AS id' )
                ->join('users','users.id','=','orders.user_id')
                ->where('orders.id', $id)
                ->first();
        $products = Orderproducts::where('order_id',$id)->get();
       
        $offer = Offerorder::where("order_id", $order->id)->first();
        
        if($offer != null &&  $offer->shippingaddress_id != null){
             $shipping_address = ShippingAddresses::where('id',$offer->shippingaddress_id)->get();
        }else{
            $shipping_address = [];
        }
        
        // dd($shipping_address);
        if($offer != null ){
            $offer_services = Offerorderservices::where("offer_id", $offer->id)->get();
            $offer_products = Offerorderproducts::where("offer_id", $offer->id)->get();
        }else{
            $offer_services = [];
            $offer_products = [];
        }
        $chat = OrderChat::where('order_id', $order->id)->get();
        $chat_count=0;
        foreach ($chat as $msg) {
            if ($msg->from == 1 && $msg->order_id == $order->id  && $msg->notification == null) {
                $chat_count++;
            }
        }
        // $chat_count = OrderChat::find(2)->where('notification', null)->count();
    //    dd($chat_count);
        return view('clients.order_offer', compact('order','chat', 'chat_count','shipping_address','offer','offer_services','offer_products','products'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }
    public function offer_accept(Request $request, $id)
    {
        Orders::find($request->order_id)->update(['order_status' => 'Offer Accepted']);
        Orders::find($request->order_id)->update([ 'active_tab' => $request->active]);
        $order = Orders::where('id', $request->order_id)->first();
        $user = User::where('id', $order->user_id)->first();
        // $admin = User::find(1);
        $admin = User::where('type', 'admin')->first();
        $details = [
                'title' => 'Notification on Order #' . $order->order_id . ' from Shopper',
                'order_number' => $order->order_id,
                'greeting' =>  $user->name. ' accept offer',
                'order_id' => $order->id,
                'description' => ''
            ];
        $admin->notify(new \App\Notifications\TaskNotification($details));

        $client = User::where('id', $order->user_id)->first();
        $details = [
            'title' => 'Notification on Order #' . $order->order_id,
            'order_number' => $order->order_id,
            'greeting' =>  'Thank you for accepting our offer',
            'order_id' => $order->id,
            'description' => 'Thank you for accepting our offer , we look forward to assist you , please proceed with the payment.'
        ];
        $client->notify(new \App\Notifications\TaskNotification($details));
        return back();
    }
    public function offer_reject(Request $request, $id)
    {
        Orders::find($request->order_id)->update(['order_status' => 'Offer Rejected']);
        $offer = Offerorder::find($id);
        $offer->update($request->all());
        Orders::find($request->order_id)->update([ 'active_tab' => $request->active]);
        $order = Orders::where('id', $request->order_id)->first();
        $user = User::where('id', $order->user_id)->first();
        // $admin = User::find(1);
        $admin = User::where('type', 'admin')->first();
        $details = [
                'title' => 'Notification on Order #' . $order->order_id . ' from Shopper',
                'order_number' => $order->order_id,
                'greeting' =>  $user->name. ' reject offer',
                'order_id' => $order->id,
                'description' => ''
            ];

        $admin->notify(new \App\Notifications\TaskNotification($details));
        return back();
    }
    public function rejected(Request $request, $id)
    {
        $request->validate([
                'reason'=>'required',
        ]);
         Offerorder::find($request->offer_id)->update([ 'rejections_note' => $request->reason]);
        return back();
    }

    public function tracking_id(Request $request, $id)
    {
        //   dd($request->all());
        $request->validate([
            'product.*.trackingid' => 'required',
            'product.*.trackinglink' => 'required',
        ]);
        foreach ($request->product as $key => $value) {
            // for product receipt image
            if (!($value['receipt'] == 'None')) {
                $name = $value['receipt']->getClientOriginalName();
                $value['receipt']->move('../public_html/uploads/productsimages', $name);
                $product = Orderproducts::find($value['product_id']);
                $product->update([
                    'receipt' => $value['receipt']->getClientOriginalName(),
                ]);
            } else {
            }
            // for tracking id's and link
            if(!(is_null($value['trackingid'])) && !(is_null($value['trackinglink']))){
                // dd('not null');
                    $product = Orderproducts::find($value['product_id']);
                    // dd($value['product_tracking_no']);
                    $product->update([
                    'trackingid' => $value['trackingid'],
                    'trackinglink' => $value['trackinglink']
                ]);
            }else{
                // dd('null');
                $product = Orders::find($request->order_id);
                $product->update([
                    'tracking_status' => 0
                ]);
            }
        }
        // dd('not in the loop');
        // for status update
        $status = Orders::find($request->order_id);    
        $status->update([
            'tracking_status' => 1
        ]);
        // status update end here
        Orders::find($request->order_id)->update(['order_status' => 'Order placed']);
        $order = Orders::where('id', $request->order_id)->first();
        $user = User::where('id', $order->user_id)->first();
        // dd($order->user_id);
        // $admin = User::find(1);
        $admin = User::where('type', 'admin')->first();
        $details = [
            'title' => 'Notification on Order #' . $order->order_id . ' from Shopper',
            'order_number' => $order->order_id,
            'greeting' =>  $user->name. " added tracking id`s",
            'order_id' => $order->id,
            'description' => ''
        ];

        $admin->notify(new \App\Notifications\TaskNotification($details));
        return back();   
    }
    public function image_upload(Request $request, $id)
    {
        
        foreach ($request->product as $key => $value) {
            if(!($value['image'] == 'None')){
                    $name = $value['image']->getClientOriginalName();
                    $value['image']->move('../public_html/uploads/productsimages', $name);
                    $product = Orderproducts::find($value['product_id']);
                    $product->update([
                        'image' => $value['image']->getClientOriginalName(),
                    ]);
                $order = Orders::where('id', $request->order_id)->first();
                $user = User::where('id', $order->user_id)->first();
                // $admin = User::find(1);
                $details = [
                    'title' => 'Notification on Order #' . $order->order_id . ' from Delivering Parcel',
                    'order_number' => $order->order_id,
                    'greeting' =>'Admin Uploaded images',
                    'order_id' => $order->id,
                    'description' => ''
                ];
                $user->notify(new \App\Notifications\TaskNotification($details));
                }else{
                    // dd('hello');
                }
            }
            foreach ($request->service as $key => $value) {
                    $product = Offerorderservices::find($value['service_id']);
                    $product->update([
                            'confirmation' => $value['servicestatus']
                        ]); 
            }
        
            Orders::find($request->order_id)->update([ 'active_tab' => $request->active]);
        // status update code
        Orders::find($request->order_id)->update([
            'order_status' => 'Confirm Shipment',
            'confirmation' => $request->confirmation
        ]);
        $order = Orders::where('id',$request->order_id)->first();
        $user = User::where('id', $order->user_id)->first();
        // $admin = User::find(1);
        $details = [
            'title' => 'Notification on Order #' . $order->order_id . ' from Delivering Parcel',
            'order_number' => $order->order_id,
            'greeting' =>'Admin need confirmation',
            'order_id' => $order->id,
            'description' => 'Please confirm the shipment to be shipped if you are happy with all the item which you have ordered , and the services been provided .so we can add the tracking number to the order .'
        ];
        $user->notify(new \App\Notifications\TaskNotification($details));
        return back();
    }
    public function Order_confirmation(Request $request, $id)
     {
        // dd($request->all());
        $request->validate([
            'product.*.weight' => 'required',
            'product.*.value' => 'required',
            'category' => 'required',
            'name'=>'required',
            'address1' => 'required',
            'city' => 'required',
            'state' => 'required',
            'postalcode' => 'required',
            'country' => 'required',
            'number' => 'required',
            
        ]);
        // dd($request->all());
        foreach ($request->product as $key => $value) {
            $product = Orderproducts::find($value['product_id']);
            // dd($value['weight']);
            $product->update([
                'custom_weight' => $value['weight'],
                'custom_value' => $value['value'],
                'custom_category' => $request->category
            ]);
        }
        // $status = Orders::find($request->order_id);  
        // dd($status);
        Orders::find($request->order_id)->update([ 
            // 'active_tab' => $request->active,
            'confirmation' => $request->confirmation,
            'custom_status' =>$request->custom_status,
            'ship_name' => $request->name,
            'ship_address1' => $request->address1,
            'ship_address2' => $request->address2,
            'ship_city' => $request->city,
            'ship_state' => $request->state,
            'ship_postalcode' => $request->postalcode,
            'ship_country' => $request->country,
            'ship_number' => $request->number,
            'custom_category' => $request->category,
            'custom_total_quantity' => $request->custom_total_quantity,
            'custom_total_weight' => $request->custom_total_weight,
            'custom_total_value' => $request->custom_total_value
            
        ]);
        $order = Orders::where('id', $request->order_id)->first();
        $user = User::where('id', $order->user_id)->first();
        // $admin = User::find(1);
        $admin = User::where('type', 'admin')->first();
        $details = [
            'title' => 'Notification on Order #' . $order->order_id . ' from Shopper',
            'order_number' => $order->order_id,
            'greeting' =>  $user->name . ' confirm to ship',
            'order_id' => $order->id,
            'description' => ''
        ];
        $admin->notify(new \App\Notifications\TaskNotification($details));
        return back();   
    }
     public function order_tracking(Request $request, $id)
    {
        // dd($request->all());
        // $status = Orders::find($request->order_id);  
        // Orders::find($request->order_id)->update(['order_status' => 'Shipped']);
        Orders::find($id)->update([ 
            'active_tab' => $request->active,
            'trackingid' => $request->trackingid,
            'trackinglink' => $request->trackinglink,
            'companyname' => $request->companyname,
            'order_status' => 'Order processing'
            ]);
        $order = Orders::where('id', $request->order_id)->first();
        $user = User::where('id', $order->user_id)->first();
        // $admin = User::find(1);
        $details = [
            'title' => 'Notification on Order #' . $order->order_id . ' from Delivering Parcel',
            'order_number' => $order->order_id,
            'greeting' =>  "Item`s shipped",
            'order_id' => $order->id,
            'description' => ''
        ];
        $user->notify(new \App\Notifications\TaskNotification($details));
        return back();    
    }
    public function Order_complete(Request $request, $id)
    {
        Orders::find($id)->update([
            'order_status' => $request->order_status
        ]);
        $order = Orders::where('id',
            $request->order_id
        )->first();
        $user = User::where('id', $order->user_id)->first();
        $admin = User::where('type', 'admin')->first();
        // $admin = User::find(1);
        $details = [
            'title' => 'Notification on Order #' . $order->order_id . ' from Shopper',
            'order_number' => $order->order_id,
            'greeting' =>  $user->name . ' marked order completed',
            'order_id' => $order->id,
            'description' => ''
        ];
        $admin->notify(new \App\Notifications\TaskNotification($details));
        
        $client = User::where('id', $order->user_id)->first();
        // $admin = User::find(1);
        $details = [
            'title' => 'Notification on Order #' . $order->order_id,
            'order_number' => $order->order_id,
            'greeting' =>  'Your order marked as completed',
            'order_id' => $order->id,
            'description' => 'Thank you for your custom and giving us chance to assist you . please leave a kind remarks for us and hope to help you again in future .'
        ];
        $client->notify(new \App\Notifications\TaskNotification($details));
        return back();
    }
    public function chat(Request $request)
    {
        // $this->validate($request, [
        //     'message' => 'required',
        // ]);
        $order = Orders::where('id',$request->order_id)->first();
        $client = User::where('id', $order->user_id)->first();
        if($request->hasfile('image') && $request->message) {
            $imageName =  $request->file('image')->getClientOriginalName();
            $request->file('image')->move(public_path() . '/uploads/chatimages', $imageName);
            $chat = new OrderChat([
                'from' => $request->user_id,
                'order_id' => $request->order_id,
                'body' => $request->message,
                'image'=> $imageName 
            ]);
            $chat->save();
            $user = User::find(auth()->user()->id);
            if ($user->roles[0]->slug == 'admin') {
                $client_id = Orders::find($request->order_id)->user_id;

                $user = User::find($client_id);
                $data = [
                    'title' => 'You have received new message from Admin on Order #' . $order->order_id,
                    // 'title' => 'Order #' . $order->order_id . ' Notification from Deliveing Parcel',
                    'greeting' => 'Admin',
                    'body' => $request->message,
                    'order_number' => $order->order_id,
                    'id' => $request->order_id,
                    'description' => ''
                ];
                $user->notify(new \App\Notifications\Chatnotification($data));
            } else {
                // $user = User::find(1);
                $user = User::where('type', 'admin')->first();
                $data = [
                    // 'title' => 'You have received new message from'. $client->name,
                    'title' => 'You have received new message from'. $client->name. 'on Order #' . $order->order_id,
                    'greeting' => $client->name,
                    'body' => $request->message,
                    'order_number' => $order->order_id,
                    'id' => $request->order_id,
                    'description' => ''
                ];
                $user->notify(new \App\Notifications\Chatnotification($data));
            }
        }
        elseif($request->hasfile('image')){
            $imageName =  $request->file('image')->getClientOriginalName();
            $request->file('image')->move('../public_html/uploads/chatimages', $imageName);
            $chat = new OrderChat([
                'from' => $request->user_id,
                'order_id' => $request->order_id,
                'image' => $imageName
            ]);
            $chat->save();
            $user = User::find(auth()->user()->id);
            if ($user->roles[0]->slug == 'admin') {
                $client_id = Orders::find($request->order_id)->user_id;

                $user = User::find($client_id);
                $data = [
                    'title' => 'You have received new message from Admin on Order #' . $order->order_id,
                    'greeting' => 'Admin',
                    'body' => $request->message,
                    'order_number' => $order->order_id,
                    'id' => $request->order_id,
                    'description' => ''
                ];
                $user->notify(new \App\Notifications\Chatnotification($data));
            } else {
                // $user = User::find(1);
                $user = User::where('type', 'admin')->first();
                $data = [
                    'title' => 'You have received new message from' . $client->name . 'on Order #' . $order->order_id,
                    'greeting' => $client->name,
                    'body' => $request->message,
                    'order_number' => $order->order_id,
                    'id' => $request->order_id,
                    'description' => ''
                ];
                $user->notify(new \App\Notifications\Chatnotification($data));
            }
        }
        elseif($request->message){
            $chat = new OrderChat([
                'from' => $request->user_id,
                'order_id' => $request->order_id,
                'body' => $request->message,
            ]);
            $chat->save();
            $user = User::find(auth()->user()->id);
            if ($user->roles[0]->slug == 'admin') {
                $client_id = Orders::find($request->order_id)->user_id;
                $user = User::find($client_id);
                $data = [
                    'title' => 'You have received new message from Admin ' . 'on Order #' . $order->order_id,
                    'greeting' => 'Admin',
                    'body' => $request->message,
                    'order_number' => $order->order_id,
                    'id' => $request->order_id,
                    'description' => ''
                ];
                $user->notify(new \App\Notifications\Chatnotification($data));
            } else {
                // $user = User::find(1);
                $user = User::where('type', 'admin')->first();
                $data = [
                    'title' => 'You have received new message from' . $client->name . 'on Order #' . $order->order_id,
                    'greeting' => $client->name,
                    'body' => $request->message,
                    'order_number' => $order->order_id,
                    'id' => $request->order_id,
                    'description' => ''
                ];
                $user->notify(new \App\Notifications\Chatnotification($data));
            }
        }else{} 
        $chat = OrderChat::where('order_id',$request->order_id)->get();
       return view('messages')->with('chat',$chat);
    }
   
    public function read_message(Request $request)
    {
        $message = OrderChat::where('order_id', $request->id)->get();
        foreach ($message as $msg) {
            if ($request->user_id != $msg->from && $msg->read == null) {
                $msg->read = 1;
                $msg->save();
            }

            if ($request->user_id != $msg->from && $msg->notification == null) {
                $msg->notification = 1;
                $msg->save();
            }
        }
        // $affected = DB::table('order_chats')
        //                 ->where('order_id', $request->id)
        //                 ->update(['read' => 1]);
        return back();
    }
    public function chat_messages(Request $request)
    {
        $message = OrderChat::where('order_id', $request->id)->get();
        // dd($message);
        $chat = null;
        foreach($message as $msg){
            if($request->user_id != $msg->from && $msg->read == null){
                $chat = OrderChat::where('order_id', $request->id)->get();
            }
            if ($request->user_id != $msg->from && $msg->read == null) {
                $msg->read = 1;
                $msg->save();
            } 
        }
        if($chat == null){
            return json_encode($chat);
        }else{
            return view('messages')->with('chat', $chat);
        }
    }
    public function chat_count(Request $request)
    {
        $message = OrderChat::where('order_id', $request->id)->get();
        $chat_count = 0;
        foreach ($message as $msg) {
            if ($request->user_id != $msg->from && $msg->notification == null) {
                $chat_count++;
            }
        }
        return $chat_count;
    }
    public function check_notification(Request $request)
    {
    //   $notification =  Notification::where('data->candidate_user_id', Auth::id())->pluck('data');
        $user = auth()->user()->id;
        $test = DB::table('notifications')->where('type', 'App\Notifications\TaskNotification')->get();
        $notification_count=0;
        foreach($test as $unread){
            if ($request->id == $unread->notifiable_id && $unread->read_at == null) {
                $notification_count++;
            }
        }
        return $notification_count;
        // dd($notification_count);
    }
    public function stripePost(Request $request)
    {
        // dd($request);
        Stripe\Stripe::setApiKey('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');
        Stripe\Charge::create([
            "amount" => $request->total * 100,
            "currency" => "usd",
            "source" => $request->stripeToken,
            "description" => "payment"
        ]);
        $offer = Offerorder::find($request->offer_id);
        $offer->update($request->all());
        session()->flash('success', 'Your payment has been successfully processed.');
        // Session::flash('success', 'Payment successful!');
        $order = Orders::where('id', $request->order_id)->first();
        $user = User::where('id',$order->user_id)->first();
        // $admin = User::find(1);
        $admin = User::where('type', 'admin')->first();
        $details = [
            'title' => 'Notification on Order #' . $order->order_id . ' from Shopper',
            'greeting' =>  $user->name . " pay's total",
            'order_number' => $order->order_id,
            'order_id' => $order->id,
            'description' => ''
        ];

        $client = User::where('id',$order->user_id)->first();
        $details = [
            'title' => 'Notification on Order #' . $order->order_id,
            'greeting' =>  "Your order has been placed",
            'order_number' => $order->order_id,
            'order_id' => $order->id,
            'description' => 'Your order has been placed, please wait till the item arrives at our address and we wil notify you '
        ];

        $client->notify(new \App\Notifications\TaskNotification($details));
        return back();
    }
    
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    
}
