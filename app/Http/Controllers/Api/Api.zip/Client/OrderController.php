<?php

namespace App\Http\Controllers\Api\Client;

use App\Http\Controllers\Controller;
use App\Models\Orders;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $q = Orders::where('user_id', $request->user()->id)
            ->with('offers')
            ->orderByDesc('id');

        if ($status = $request->input('status')) {
            $q->where('order_status', $status);
        }

        $perPage = min((int) $request->input('per_page', 20), 50);
        return response()->json($q->paginate($perPage));
    }

    public function show(Request $request, Orders $order): JsonResponse
    {
        abort_unless($order->user_id === $request->user()->id, 404);

        $order->load([
            'offers' => fn($q) => $q->orderByDesc('id'),
            'offers.offerorderservices',
            'offers.offerorderproducts',
            'order_chats' => fn($q) => $q->orderByDesc('id')->limit(50),
        ]);

        // Load payments directly (Orders model has no payments relationship)
        $order->payments = \App\Models\Payment::where('order_id', $order->id)
            ->orderByDesc('id')
            ->get();

        return response()->json(['order' => $order]);
    }
}
