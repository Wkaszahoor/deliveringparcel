<?php

namespace App\Http\Controllers\Api\Client;

use App\Http\Controllers\Controller;
use App\Models\Orders;
use App\Models\Payment;
use App\Models\PaymentMethod;
use App\Services\Payments\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function methods(): JsonResponse
    {
        $methods = PaymentMethod::where('is_active', true)
            ->orderByDesc('sort_order')
            ->get()
            ->map(fn($m) => [
                'id'   => $m->id,
                'code' => $m->code,
                'name' => $m->name,
            ]);

        return response()->json(['methods' => $methods]);
    }

    public function initiate(Request $request, Orders $order): JsonResponse
    {
        abort_unless($order->user_id === $request->user()->id, 404);

        $data = $request->validate([
            'payment_method_id' => 'required|integer|exists:payment_methods,id',
        ]);

        try {
            $result = app(PaymentService::class)->initiateFromOffer(
                $order->id,
                $request->user()->id,
                $data['payment_method_id']
            );

            return response()->json([
                'message'        => 'Payment initiated.',
                'payment_id'     => $result['payment_id'] ?? null,
                'checkout_url'   => $result['checkout_url'] ?? null,
                'client_secret'  => $result['client_secret'] ?? null,
                'status'         => $result['status'] ?? 'pending',
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'message' => 'Payment initiation failed: ' . $e->getMessage(),
            ], 422);
        }
    }

    public function status(Request $request, Orders $order): JsonResponse
    {
        abort_unless($order->user_id === $request->user()->id, 404);

        $payment = Payment::where('order_id', $order->id)
            ->orderByDesc('id')
            ->first();

        if (!$payment) {
            return response()->json(['status' => 'no_payment', 'payment' => null]);
        }

        // Auto-verify if still in open status
        if ($payment->isOpen() && $payment->gateway === 'stripe') {
            try {
                $verified = app(PaymentService::class)->verifyPayment($payment->id);
                if ($verified) {
                    $payment->refresh();
                }
            } catch (\Throwable $e) {
                // Best-effort verification
            }
        }

        return response()->json([
            'status'  => $payment->status,
            'payment' => [
                'id'             => $payment->id,
                'amount'         => $payment->amount,
                'currency'       => $payment->currency,
                'status'         => $payment->status,
                'state_label'    => $payment->stateLabel(),
                'gateway'        => $payment->gateway,
                'paid_at'        => optional($payment->paid_at)->toDateTimeString(),
                'failure_reason' => $payment->friendlyFailure(),
            ],
        ]);
    }
}
