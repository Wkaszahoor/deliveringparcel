<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BankAccount;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Config;

/**
 * Payment API Controller
 * 
 * Provides API endpoints for payment-related frontend integration
 */
class PaymentApiController extends Controller
{
    /**
     * Get bank account details for bank transfer payments
     * 
     * @return JsonResponse
     */
    public function bankAccountDetails(): JsonResponse
    {
        // Get the first enabled bank account
        $bankAccount = BankAccount::enabled()->ordered()->first();

        if (!$bankAccount) {
            return response()->json([
                'ok' => false,
                'account' => null,
                'message' => 'No enabled bank account found'
            ], 404);
        }

        return response()->json([
            'ok' => true,
            'account' => [
                'bank_name' => $bankAccount->bank_name,
                'account_title' => $bankAccount->account_title,
                'account_number' => $bankAccount->account_number,
                'iban' => $bankAccount->iban,
                'branch' => $bankAccount->branch,
                'swift_code' => $bankAccount->swift_code,
                'currency' => $bankAccount->currency,
                'instructions' => $bankAccount->instructions,
            ]
        ]);
    }

    /**
     * Get Stripe configuration for frontend Elements integration
     * 
     * @return JsonResponse
     */
    public function stripeConfig(): JsonResponse
    {
        $publishableKey = trim((string) config('services.stripe.key'));

        return response()->json([
            'ok' => true,
            'publishable_key' => $publishableKey ?: null,
            'configured' => !empty($publishableKey),
        ]);
    }
}
