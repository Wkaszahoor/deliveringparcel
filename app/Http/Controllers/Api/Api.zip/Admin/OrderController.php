<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Offerorder;
use App\Models\Orders;
use App\Models\Payment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $q = Orders::with('offers');

        // Advanced search (mirrors web admin-orders filters)
        if ($id = $request->input('order_id')) {
            $q->where('order_id', 'like', "%{$id}%");
        }
        if ($name = $request->input('name')) {
            $q->whereHas('user', fn($u) => $u->where('name', 'like', "%{$name}%"));
        }
        if ($email = $request->input('email')) {
            $q->whereHas('user', fn($u) => $u->where('email', 'like', "%{$email}%"));
        }
        if ($from = $request->input('shipfrom')) {
            $q->where('shipfrom', 'like', "%{$from}%");
        }
        if ($to = $request->input('shipto')) {
            $q->where('shipto', 'like', "%{$to}%");
        }
        if (($status = $request->input('status')) !== null && $status !== '') {
            $q->where('order_status', $status);
        }

        $perPage = min((int) $request->input('per_page', 20), 50);
        $orders  = $q->orderByDesc('id')->paginate($perPage);

        return response()->json($orders);
    }

    public function show(Orders $order): JsonResponse
    {
        $order->load([
            'offers' => fn($q) => $q->orderByDesc('id'),
            'offers.offerorderservices',
            'offers.offerorderproducts',
            'order_chats' => fn($q) => $q->orderByDesc('id')->limit(50),
        ]);

        // Load payments directly (Orders model has no payments relationship)
        $order->payments = Payment::where('order_id', $order->id)
            ->orderByDesc('id')
            ->get();

        return response()->json(['order' => $order]);
    }

    public function updateStatus(Request $request, Orders $order): JsonResponse
    {
        $data = $request->validate([
            'order_status' => 'required|string',
        ]);

        $newStatus = $data['order_status'];
        $statuses  = config('admin_orders.statuses', []);

        if (!isset($statuses[$newStatus])) {
            return response()->json(['message' => "Unknown status: {$newStatus}"], 422);
        }

        $current = $order->order_status ?? '';
        $allowed = $statuses[$current]['next'] ?? [];

        if (!in_array($newStatus, $allowed, true)) {
            return response()->json([
                'message' => "Cannot transition from \"{$current}\" to \"{$newStatus}\".",
            ], 422);
        }

        $order->update(['order_status' => $newStatus]);

        return response()->json([
            'message' => 'Status updated.',
            'order'   => ['id' => $order->id, 'order_status' => $order->fresh()->order_status],
        ]);
    }

    public function updateDetails(Request $request, Orders $order): JsonResponse
    {
        $data = $request->validate([
            'trackingid'    => 'nullable|string|max:255',
            'trackinglink'  => 'nullable|url|max:500',
            'tracking_status' => 'nullable|string|max:255',
            'ship_name'     => 'nullable|string|max:255',
            'ship_address1' => 'nullable|string|max:255',
            'ship_address2' => 'nullable|string|max:255',
            'ship_city'     => 'nullable|string|max:255',
            'ship_state'    => 'nullable|string|max:255',
            'ship_postalcode' => 'nullable|string|max:50',
            'ship_country'  => 'nullable|string|max:100',
            'ship_number'   => 'nullable|string|max:100',
        ]);

        $order->update(array_filter($data, fn($v) => $v !== null));

        return response()->json(['message' => 'Details updated.', 'order' => $order->fresh()]);
    }

    public function storeOffer(Request $request, Orders $order): JsonResponse
    {
        $data = $request->validate([
            'total'         => 'required|numeric|min:0',
            'description'   => 'nullable|string|max:2000',
            'product_total' => 'nullable|numeric|min:0',
        ]);

        $offer = Offerorder::updateOrCreate(
            ['order_id' => $order->id],
            [
                'total'         => $data['total'],
                'description'   => $data['description'] ?? null,
                'product_total' => $data['product_total'] ?? 0,
                'offer_status'  => 0,
            ]
        );

        $order->update(['order_status' => 'Offer Placed']);

        // Notify client
        $client = \App\Models\User::find($order->user_id);
        if ($client) {
            $client->notify(new \App\Notifications\TaskNotification([
                'title'       => 'New offer on Order #' . $order->order_id,
                'order_id'    => $order->id,
                'greeting'    => 'Admin has placed an offer for $' . number_format($data['total'], 2),
                'description' => 'Please review and accept or reject the offer.',
            ]));
        }

        return response()->json(['message' => 'Offer saved.', 'offer' => $offer]);
    }
}
