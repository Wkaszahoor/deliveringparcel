<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Orders;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $statuses = config('admin_orders.statuses', []);

        $counts = [];
        foreach ($statuses as $key => $cfg) {
            $label = $cfg['label'];
            $counts[$label] = Orders::where('order_status', $key === '' ? null : $key)->count();
        }

        $totalOrders   = Orders::count();
        $totalClients  = User::where('type', 'client')->count();
        $totalRevenue  = (float) Payment::where('status', 'paid')->sum('amount');
        $unreadNotifs  = $request->user()->unreadNotifications()->count();

        $recentOrders = Orders::with('user')
            ->orderByDesc('id')
            ->limit(10)
            ->get()
            ->map(fn($o) => [
                'id'           => $o->id,
                'order_id'     => $o->order_id,
                'status'       => $o->order_status ?? '',
                'status_label' => $statuses[$o->order_status ?? '']['label'] ?? 'Unknown',
                'client'       => $o->user->name ?? null,
                'created'      => optional($o->created_at)->toDateTimeString(),
            ]);

        return response()->json([
            'counts'        => $counts,
            'total_orders'  => $totalOrders,
            'total_clients' => $totalClients,
            'total_revenue' => $totalRevenue,
            'unread_notifications' => $unreadNotifs,
            'recent_orders' => $recentOrders,
        ]);
    }
}
